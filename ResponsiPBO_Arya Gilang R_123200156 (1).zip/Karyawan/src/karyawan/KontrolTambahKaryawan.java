/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;
import javax.swing.JOptionPane;
import karyawan.InputModel;
import karyawan.TambahKaryawan;
/**
/**
 *
 * @author ASUS
 */
public class KontrolTambahKaryawan {
    public void prosesdaftar(String nama, String usia, String gaji) {
        //instansiasi daftar sebagai bagian dari Akunmodel
        InputModel daftar = new InputModel();
        //melakukan method insertdaftar untuk medaftarkan diri
        daftar.insertdaftar( nama, usia, gaji);
        String INFO_MESSAGE = "berhasil signup";
        JOptionPane.showMessageDialog(null,INFO_MESSAGE);
        //
        this.kembali();
    }
    
    public void kembali(){
        new MainMenu().show();
    } 
}
