/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author ASUS
 */
public class Koneksi {

    /**
     * @param args the command line arguments
     */
    String url = "jdbc:mysql://localhost/karyawan";
    String username = "root";
    String password = "";
    public Connection koneksi;
    public Statement statement;
    public ResultSet resultSet;
    
    public Koneksi(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            koneksi =(Connection) DriverManager.getConnection(url, username, password);
            System.out.println("Konek");
        }catch(ClassNotFoundException | SQLException ex){
            System.out.println("Gagal Konek");
        }
    }
   
}
