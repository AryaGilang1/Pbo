/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;
import karyawan.Koneksi;
import javax.swing.JOptionPane;
/**
 *
 * @author ASUS
 */
public class DataModel {
    public void update(String id, String nama, String usia, String gaji) {
        Koneksi k = new Koneksi();
        try {
            k.statement = k.koneksi.createStatement();
            k.statement.executeUpdate("UPDATE data set " 
            + "nama     ='"     + nama   + "', "
            + "usia    ='"      + usia   + "', "
            + "gaji   ='"       + gaji   + "'  "       
            + "WHERE id_pemesanan ='" +id+   "'");
        
        } catch (Exception e) {
        e.printStackTrace();
      }
    }

    //methode delete
    public void delete(String id) {
         Koneksi k = new Koneksi();
        int jawab;
        try {
            if ((jawab = JOptionPane.showConfirmDialog(null, "Ingin menghapus data?", "konfirmasi", JOptionPane.YES_NO_OPTION)) == 0) {
                k.statement = k.koneksi.createStatement();
                k.statement.executeUpdate("DELETE FROM data WHERE id_pesanan='" +id+ "'");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //methode simpan
    public void simpan(String nama, String usia, String gaji) {
        Koneksi k = new Koneksi();
        try {
            String query = "INSERT INTO `data`(`nama`, `usia`,'gaji')"
                           +" VALUES ('"+nama+"','"+usia+"','"+gaji+"')";
            k.statement = k.koneksi.createStatement();
            k.statement.executeUpdate(query);
        
        } catch (Exception e) {
        e.printStackTrace();
      }
    }
}
